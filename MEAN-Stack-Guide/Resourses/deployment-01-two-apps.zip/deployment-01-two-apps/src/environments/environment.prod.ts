export const environment = {
  production: true,
  apiUrl: "http://meantest-env.m5qm3nbaay.us-east-1.elasticbeanstalk.com/api"
};
